import setuptools

setuptools.setup(
    name="tfidf_transformation_berk",
    version="0.1.0",
    author="Berk Ozturk",
    description="a package for tf-idf transformation with using sklearn's tfidf function ",
    packages=["tfidf_transformation_berk"]
)